sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"../util/Formatter",
	"../util/Constants",
	'sap/m/MessageToast'
],
/**
 * @param {typeof sap.ui.core.mvc.Controller} Controller
 */
function(Controller, formatter, Constants, MessageToast) {
	"use strict";

	return Controller.extend("zpokemonapp.controller.PokemonDetail", {
		formatter: formatter,
		/**
			* On load of detail view model and other data is initialized
		*/
		onInit: function() {
			this._oModelData = this.getOwnerComponent().getModel(Constants.ModelNames.POKEMON_DETAIL_MODEL);
			this._oCurrentData = {
				id: this._oModelData.oData.id,
				commentVal: this._oModelData.oData.commentValue,
				isFavorite: this._oModelData.oData.isFavorite
			};
		},
		/**
			* On save, comment data will be stored in local storage
		*/
		saveComment: function() {
			var oStorage = jQuery.sap.storage(jQuery.sap.storage.Type.local);
			if (oStorage.get(Constants.KeyConstants.LOCAL_DATA)) {
				var prevData = oStorage.get(Constants.KeyConstants.LOCAL_DATA);
			}
			var commentVal = this.getView().byId("commentText").getValue();
			this._oModelData.oData.commentValue = commentVal;
			var localData = [];
			var loopCount = 0;
			this._oCurrentData.id = this._oModelData.oData.id;
			this._oCurrentData.commentVal = this._oModelData.oData.commentValue;
			if (this._oModelData.oData.isFavorite) {
				this._oCurrentData.isFavorite = this._oModelData.oData.isFavorite;
			} else {
				this._oCurrentData.isFavorite = false;
			}
			if (prevData) {
				for (var i = 0; i < prevData.length; i++) {
					if (prevData[i].id === this._oCurrentData.id) {
						localData.push(this._oCurrentData);
					} else {
						loopCount++;
						localData.push(prevData[i]);
					}
				}
				if (loopCount === prevData.length) {
					localData.push(this._oCurrentData);
				}
			} else {
				localData.push(this._oCurrentData);
			}
			oStorage.put(Constants.KeyConstants.LOCAL_DATA, localData);
			MessageToast.show("Hurray!!! Your comment saved successfully");
		},
		/**
			* On click of mark as favorite, favorites data will be stored in local storage
		*/
		markFavPress: function() {
			var oStorageForFav = jQuery.sap.storage(jQuery.sap.storage.Type.local);
			var localFavData = [];
			var count = 0;
			if (oStorageForFav.get(Constants.KeyConstants.LOCAL_DATA)) {
				var prevFavData = oStorageForFav.get(Constants.KeyConstants.LOCAL_DATA);
			}
			if (Constants.KeyConstants.IS_FAVORITE === true) {
				Constants.KeyConstants.IS_FAVORITE = false;
				this._oModelData.oData.isFavorite = false;
				MessageToast.show("Hurray!!! You have successfully unmarked this from favorites");
			} else {
				Constants.KeyConstants.IS_FAVORITE = true;
				this._oModelData.oData.isFavorite = true;
				MessageToast.show("Hurray!!! You have successfully marked this as favorite");
			}
			this._oCurrentData.id = this._oModelData.oData.id;
			if (this._oModelData.oData.commentValue) {
				this._oCurrentData.commentVal = this._oModelData.oData.commentValue;
			} else {
				this._oCurrentData.commentVal = "";
			}
			this._oCurrentData.isFavorite = this._oModelData.oData.isFavorite;
			if (prevFavData) {
				for (var i = 0; i < prevFavData.length; i++) {
					if (prevFavData[i].id === this._oCurrentData.id) {
						localFavData.push(this._oCurrentData);
					} else {
						count++;
						localFavData.push(prevFavData[i]);
					}
					if (count === prevFavData.length) {
						localFavData.push(this._oCurrentData);
					}
				}
			} else {
				localFavData.push(this._oCurrentData);
			}
			oStorageForFav.put(Constants.KeyConstants.LOCAL_DATA, localFavData);

			this._oModelData.updateBindings();
		}
	});
});