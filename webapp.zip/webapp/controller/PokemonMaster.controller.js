sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"../model/models",
	"../util/Constants",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"../util/Formatter",
	"../util/Util"
],
/**
 * @param {typeof sap.ui.core.mvc.Controller} Controller
 */
function(Controller, Model, Constants, Filter, FilterOperator, formatter, Util) {
	"use strict";
	return Controller.extend("zpokemonapp.controller.PokemonMaster", {
		formatter: formatter,
		/**
			* This methods sets the data from model to master Table
		*/
		onInit: function() {
			var oSelf = this;
			var aResponses = [];
			Util.showBusyDialog("Loading Data","We are fetching pokemon data!!! Hang tight!!!");
			Model.getPokemonTableData(function(oResponseData) {
				aResponses.push(oResponseData);
				oSelf.getOwnerComponent().getModel(Constants.ModelNames.POKEMON_TABLE_MODEL).setData(aResponses);
				setTimeout(function () {
					Util.closeBusyDialog();
				}.bind(this), 2000);
				
			});
			this.getOwnerComponent().getRouter().getRoute("pokemonDetails").attachPatternMatched(this._onRouteMatched, this);
		},
		/**
			* On selection of an item from master table, pokemon details are displayed
			* @param {oEvent}  Event object consisting of an ID, a source and a map of parameters
		*/
		onSelectionChange: function(oEvent) {
			var sPokemonId = oEvent.getSource().getSelectedItem().getBindingContext(Constants.ModelNames.POKEMON_TABLE_MODEL).getProperty("id");
			this.getOwnerComponent().getRouter().navTo("pokemonDetails", {
				pokemonId: sPokemonId
			});
		},
		/**
			* On selection of an item from master table, required route to detail screen is added for navigation
			* @param {oEvent}  Event object consisting of an ID, a source and a map of parameters
		*/
		_onRouteMatched: function(oEvent) {
			Util.showBusyDialog("Loading Pokemon Details!!!");
			var oTableData = this.getOwnerComponent().getModel(Constants.ModelNames.POKEMON_TABLE_MODEL).getData();
			var pokemonId = oEvent.getParameter("arguments").pokemonId;
			var oSelf = this;
			var evoArray = [];
			oTableData.forEach(function(oItem) {
				if (oItem.id === parseInt(pokemonId)) {
					Model.getPokemonLocationData(pokemonId, function(oResponseData) {
						if (oResponseData.statusText === "error") {
							oItem.location = "Not Found";
						} else {
							oItem.location = oResponseData.name;
						}
						if(oResponseData.EvoData){
							for(i=0;i<oResponseData.EvoData.length;i++){
								oTableData.forEach(function(oEvoItem) {
									if (oResponseData.EvoData[i].includes(oEvoItem.name)) {
										evoArray.push(oEvoItem)
										//oItem.evolutionChain.push(oEvoItem);	
									}
								});
							}
							oItem.evolutionChain = evoArray;
						}
						else{
							oItem.evolutionChain = [];
						}
						var oStorage = jQuery.sap.storage(jQuery.sap.storage.Type.local);
						if (oStorage.get(Constants.KeyConstants.LOCAL_DATA)) {
							var oLocalData = oStorage.get(Constants.KeyConstants.LOCAL_DATA);
							for (var i = 0; i < oLocalData.length; i++) {
								if (oLocalData[i].id === oItem.id) {
									oItem.commentValue = oLocalData[i].commentVal;
									oItem.isFavorite = oLocalData[i].isFavorite;
								}
							}
						}													
						oSelf.getOwnerComponent().getModel(Constants.ModelNames.POKEMON_DETAIL_MODEL).setData(oItem);
						oSelf.getOwnerComponent().getModel(Constants.ModelNames.POKEMON_DETAIL_MODEL).updateBindings();	
						Util.closeBusyDialog();					
					});
				}
			});
		},
		/**
			* This method provides the search results from master table
			* @param {oEvent}  Event object consisting of an ID, a source and a map of parameters
		*/
		handleSearch: function(oEvent) {
			// add filter for search
			var aFilters = [];
			var sQuery = oEvent.getSource().getValue();
			if (sQuery && sQuery.length > 0) {
				var filter = new Filter("name", FilterOperator.Contains, sQuery);
				aFilters.push(filter);
			}
			// update list binding
			var oList = this.byId("pokemonMasterList");
			var oBinding = oList.getBinding("items");
			oBinding.filter(aFilters, "Application");
		}
	});
});