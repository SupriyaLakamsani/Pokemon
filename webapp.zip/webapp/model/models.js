sap.ui.define([
	"sap/ui/model/json/JSONModel",
	"sap/ui/Device",
	"../util/Constants"
], function(JSONModel, Device, Constants) {
	"use strict";

	return {
		/**
			* Creating the main model and setting the binding mode
		*/
		createDeviceModel: function() {
			var oModel = new JSONModel(Device);
			oModel.setDefaultBindingMode("OneWay");
			return oModel;
		},
		/**
			* Method to get pokemon location data by calling an api
			* @param {pokemonId}  pokemonId string consisting of an ID, fnCallback call back 
			* @param {fnCallback}  fnCallback callback function to send data to controller
		*/
		getPokemonLocationData: function(pokemonId, fnCallback) {
			var sUrl = Constants.ServicePaths.BASE_SERVICE + "/location/" + pokemonId;
			var oEvoRespData = [];
			var oSelf = this;
			
			
			$.ajax({
				url: sUrl,
				method: "GET",
				timeout: 20000,
				crossDomain: true,
				headers: {
					"Accept": "application/json; odata=verbose"
				},
				success: function(oLocResponse) {
					oSelf.getSpeciesData(pokemonId,function(evolutionChain) {
						var evolutionArray = oSelf.parseEvolution(evolutionChain.chain,oSelf);
						oLocResponse.EvoData = evolutionArray;
						fnCallback(oLocResponse);
					});
					
					
				},
				error: function(oError) {
					fnCallback(oError);
				}
			});
		},
		/**
			* Method to get pokemon data to show in master table
			* @param {fnCallback}  fnCallback callback function to send data to controller
		*/
		getPokemonTableData: function(fnCallback) {
			for (var i = 1; i <= 150; i++) {
				var sUrl = Constants.ServicePaths.BASE_SERVICE + "/pokemon/" + i;
				$.ajax({
					url: sUrl,
					method: "GET",
					timeout: 20000,
					crossDomain: true,
					headers: {
						"Accept": "application/json; odata=verbose"
					},
					success: function(oResponse) {
						fnCallback(oResponse);
					}
				});
			}
		},
		/**
			* Method to get pokemon species data which will be used to fetch evolution data
			* @param {pokemonId}  pokemonId string consisting of an ID, fnCallback call back 
			* @param {fnCallback}  fnCallback callback function to send data to controller
		*/
		getSpeciesData : function(pokemonId,fnCallback){
			var sUrl = Constants.ServicePaths.BASE_SERVICE + "/pokemon-species/" + pokemonId;
			var oSelf = this;
			$.ajax({
				url: sUrl,
				method: "GET",
				timeout: 20000,
				crossDomain: true,
				headers: {
					"Accept": "application/json; odata=verbose"
				},
				success: function(oSpeciesResponse) {
					oSelf.getEvolutionData(oSpeciesResponse.evolution_chain.url,function(oEvolutionResponse){
						fnCallback(oEvolutionResponse);
					});
				}
			});
		},
		/**
			* Method to get pokemon evolution data
			* @param {sEvoUrl}  sEvoUrl api url to get specific pokemon evolution
			* @param {fnCallback}  fnCallback callback function to send data to controller
		*/
		getEvolutionData : function(sEvoUrl,fnCallback){
			$.ajax({
				url: sEvoUrl,
				method: "GET",
				timeout: 20000,
				crossDomain: true,
				headers: {
					"Accept": "application/json; odata=verbose"
				},
				success: function(oEvoChainResponse) {
					fnCallback(oEvoChainResponse);
				}
			});
		},
		/**
			* Method to format pokemon evolution data
			* @param {evolutionChain}  evolutionChain object containing evolution details
		*/
		 parseEvolution : function(evolutionChain) {
			var evolutionArray = [[evolutionChain.species.name]];
			var evolutionQueue = [evolutionChain.evolves_to];
		
			// follow evolution chain (nested in JSON) until queue is "empty"
			while (evolutionQueue[0] !== undefined && evolutionQueue[0].length !== 0) {
			  evolutionChain = evolutionQueue.shift();
			  var subEvolutionArray = [];
		
			  // iterates through all pokémon that evolves from current species
			  for (var field in evolutionChain) {
		
				// number represents a key to evolved pokémon
				if (!isNaN(parseInt(field))) {
				  subEvolutionArray.push(evolutionChain[field].species.name);
				  evolutionQueue.push(evolutionChain[field].evolves_to);
				}
			  }
			  evolutionArray.push(subEvolutionArray);
			}
			return evolutionArray;
		  }
	};
});