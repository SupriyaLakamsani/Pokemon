/*global QUnit*/
sap.ui.define([
	"zpokemon_app/model/models",
	"sap/ui/Device"
], function (models, Device) {
	"use strict";

	QUnit.module("createDeviceModel");
	QUnit.test("The binding mode of the device model should be one way", function (assert) {
		this.oDeviceModel = models.createDeviceModel();
		assert.strictEqual(this.oDeviceModel.getDefaultBindingMode(), "OneWay", "Binding mode is correct");
	})
});