/*global QUnit*/

sap.ui.define([
	"zpokemon_app/controller/PokemonMain.controller"
], function (Controller) {
	"use strict";

	QUnit.module("PokemonMain Controller");

	QUnit.test("PokemonMain controller initialized", function (assert) {
		var oAppController = new Controller();
		oAppController.onInit();
		assert.ok(oAppController);
	});

});
