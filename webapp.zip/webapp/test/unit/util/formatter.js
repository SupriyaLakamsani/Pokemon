/*global QUnit*/
sap.ui.define([
	"zpokemon_app/util/Formatter"
], function (formatter) {
	"use strict";
    QUnit.module("showFavTxt");
    function FavTstCase(oOptions) {
		// Act
		var sState = formatter.showFavType(oOptions.status);

		// Assert
		oOptions.assert.strictEqual(sState, oOptions.expected, "The state was correct");
	}

	QUnit.test("Should display green color when saved as favorite", function (assert) {
		FavTstCase.call(this, {
			assert: assert,
			status: true,
			expected: "Success"
		});
	});

	QUnit.test("Should display blue color when not saved as favorite", function (assert) {
		FavTstCase.call(this, {
			assert: assert,
			status: false,
			expected: "Emphasized"
		});
	})
});