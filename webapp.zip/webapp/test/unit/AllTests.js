sap.ui.define([
	"./model/models",
	"./util/formatter",
    "./controller/PokemonMain.controller"
], function() {
	"use strict";
});