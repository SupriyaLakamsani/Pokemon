sap.ui.define([], function() {
	return {
		fragments: {

		},
		ServicePaths: {
			BASE_SERVICE: "https://pokeapi.co/api/v2"
		},
		ModelNames: {
			POKEMON_TABLE_MODEL: "PokemonTableModel",
			POKEMON_DETAIL_MODEL: "PokemonDetailModel"
		},
		KeyConstants: {
			LOCAL_DATA: [],
			IS_FAVORITE: false,
			LOCAL_FAV_DATA: []
		}
	};
});