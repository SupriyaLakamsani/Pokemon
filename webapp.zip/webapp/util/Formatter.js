sap.ui.define([], function() {
	"use strict";

	return {
		formatAbilitiesTxt: function(aAbilities) {
			var abilityText = "";
			if (aAbilities) {
				for (var i = 0; i < aAbilities.length; i++) {
					abilityText = abilityText + "," + aAbilities[i].ability.name;
				}
				return abilityText.substring(1);
			}
		},
		showFavTxt: function(isFav) {
			if (isFav === true) {
				return "Favorite";
			}
			return "Mark as Favorite";
		},
		showFavType: function(isFav) {
			if (isFav === true) {
				return "Success";
			}
			return "Emphasized";
		}

	};
});