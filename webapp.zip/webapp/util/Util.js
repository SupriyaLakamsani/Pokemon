sap.ui.define(["sap/m/MessageToast"], function (MessageToast) {
	"use strict";
	return {
		/**
		 * @function showToastMsg
		 * This method is to show the toast Message
		 * @param {String} sMsg- message to be shown
		 */
		showToastMsg: function (sMsg) {
			MessageToast.show(sMsg);
		},
		/**
		 * @function closeBusyDialog
		 * @summary This method is to show the busy dialog
		 * @param {String} sText- message to be shown
		 */
		showBusyDialog: function (sTitle,sText) {
			if (!this._busyDialog) {
				this._busyDialog = new sap.m.BusyDialog({});
			}
			this._busyDialog.setTitle(sTitle);
			this._busyDialog.setText(sText);
			this._busyDialog.open();
		},
		/**
		 * @function closeBusyDialog
		 * @summary This method closes the busy dialog
		 */
		closeBusyDialog: function () {
			if (this._busyDialog) {
				this._busyDialog.close();
			}
		}
	};
});